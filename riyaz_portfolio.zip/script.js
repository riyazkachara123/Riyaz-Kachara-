// Simple JavaScript example
console.log("Welcome to Riyaz's Portfolio!");